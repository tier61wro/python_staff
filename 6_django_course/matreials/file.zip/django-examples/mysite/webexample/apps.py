from django.apps import AppConfig


class WebexampleConfig(AppConfig):
    name = 'webexample'
